package com.histflags.keyboard

import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class HistFlagsImeService : InputMethodService() {
    data class Flag(val title: String, val value: String, val category: String)

    private val allFlags = listOf(
        Flag("Российская империя", "Российская империя", "Россия"),
        Flag("СССР", "СССР", "СССР"),
        Flag("РСФСР", "РСФСР", "Россия"),
        Flag("Царская Россия", "Российская империя", "Россия"),
        Flag("Германская империя", "Германская империя", "Германия"),
        Flag("ГДР", "ГДР", "Германия"),
        Flag("Пруссия", "Пруссия", "Германия"),
        Flag("Австро-Венгрия", "Австро-Венгрия", "Европа"),
        Flag("Византия", "Византийская империя", "Европа"),
        Flag("Римская империя", "Римская империя", "Европа"),
        Flag("Османская империя", "Османская империя", "Европа"),
        Flag("🇷🇺 Россия", "🇷🇺", "Россия"),
        Flag("🇩🇪 Германия", "🇩🇪", "Германия"),
        Flag("🇫🇷 Франция", "🇫🇷", "Европа"),
        Flag("🇬🇧 Британия", "🇬🇧", "Европа"),
        Flag("🇺🇸 США", "🇺🇸", "Америка")
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(3), dp(5), dp(3))
            setBackgroundColor(Color.rgb(245,245,245))
        }

        val toolbar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "🏴 Исторические флаги"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(35,35,35))
        }
        toolbar.addView(title, LinearLayout.LayoutParams(0, dp(46), 1f))

        val delete = Button(this).apply {
            text = "⌫"
            textSize = 19f
            isAllCaps = false
            setOnClickListener { currentInputConnection?.deleteSurroundingText(1,0) }
        }
        toolbar.addView(delete, LinearLayout.LayoutParams(dp(52), dp(46)))
        root.addView(toolbar)

        val search = EditText(this).apply {
            hint = "Поиск флага…"
            singleLine = true
            textSize = 14f
            setPadding(dp(12), 0, dp(12), 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(42)).apply {
            setMargins(dp(3), dp(2), dp(3), dp(4))
        })

        val catsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val cats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Все","Россия","СССР","Германия","Европа","Америка","Избранное").forEach { name ->
            val b = Button(this).apply {
                text = name
                isAllCaps = false
                textSize = 12f
            }
            cats.addView(b, LinearLayout.LayoutParams(-2, dp(42)).apply {
                setMargins(dp(2),0,dp(2),0)
            })
        }
        catsScroll.addView(cats)
        root.addView(catsScroll)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun render(query: String = "", category: String = "Все") {
            list.removeAllViews()
            val q = query.trim().lowercase(Locale.getDefault())
            val filtered = allFlags.filter {
                (category == "Все" || it.category == category) &&
                (q.isEmpty() || it.title.lowercase(Locale.getDefault()).contains(q))
            }

            filtered.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                }
                pair.forEach { flag ->
                    val b = Button(this).apply {
                        text = "🏴\n${flag.title}"
                        isAllCaps = false
                        textSize = 12f
                        gravity = Gravity.CENTER
                        setOnClickListener {
                            currentInputConnection?.commitText(flag.value, 1)
                        }
                    }
                    row.addView(b, LinearLayout.LayoutParams(0, dp(78), 1f).apply {
                        setMargins(dp(3),dp(3),dp(3),dp(3))
                    })
                }
                if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0,dp(78),1f))
                list.addView(row)
            }
        }

        render()
        search.setOnEditorActionListener { _,_,_ -> render(search.text.toString()); true }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("⌨","😀","🏴","⚙").forEach {
            val b = Button(this).apply { text=it; textSize=21f; isAllCaps=false }
            bottom.addView(b, LinearLayout.LayoutParams(0,dp(48),1f))
        }
        root.addView(bottom)
        return root
    }
}
